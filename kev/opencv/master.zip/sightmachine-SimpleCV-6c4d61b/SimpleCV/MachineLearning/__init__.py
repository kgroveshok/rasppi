from SimpleCV.MachineLearning.SVMClassifier import *
from SimpleCV.MachineLearning.TreeClassifier import *
from SimpleCV.MachineLearning.KNNClassifier import *
from SimpleCV.MachineLearning.NaiveBayesClassifier import *
from SimpleCV.MachineLearning.ShapeContextClassifier import *
from SimpleCV.MachineLearning.ConfusionMatrix import *
from SimpleCV.MachineLearning.TurkingModule import *
from SimpleCV.MachineLearning.TemporalColorTracker import *
