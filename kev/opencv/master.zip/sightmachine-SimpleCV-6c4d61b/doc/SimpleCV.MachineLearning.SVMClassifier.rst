SimpleCV.MachineLearning.SVMClassifier module
=============================================

.. automodule:: SimpleCV.MachineLearning.SVMClassifier
    :members:
    :show-inheritance:
