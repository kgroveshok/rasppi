SimpleCV.LineScan module
========================

.. automodule:: SimpleCV.LineScan
    :members:
    :show-inheritance:
