SimpleCV.ImageClass module
==========================

.. automodule:: SimpleCV.ImageClass
    :members:
    :show-inheritance:
