SimpleCV.Segmentation.MOGSegmentation module
============================================

.. automodule:: SimpleCV.Segmentation.MOGSegmentation
    :members:
    :show-inheritance:
