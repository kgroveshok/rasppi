SimpleCV.Tracking.CAMShiftTracker module
========================================

.. automodule:: SimpleCV.Tracking.CAMShiftTracker
    :members:
    :show-inheritance:
