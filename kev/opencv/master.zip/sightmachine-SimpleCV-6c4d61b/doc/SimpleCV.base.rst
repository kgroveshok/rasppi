SimpleCV.base module
====================

.. automodule:: SimpleCV.base
    :members:
    :show-inheritance:
