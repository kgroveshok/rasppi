SimpleCV.Segmentation.ColorSegmentation module
==============================================

.. automodule:: SimpleCV.Segmentation.ColorSegmentation
    :members:
    :show-inheritance:
