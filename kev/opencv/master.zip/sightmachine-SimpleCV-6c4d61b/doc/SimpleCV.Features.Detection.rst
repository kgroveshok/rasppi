SimpleCV.Features.Detection module
==================================

.. automodule:: SimpleCV.Features.Detection
    :members:
    :show-inheritance:
