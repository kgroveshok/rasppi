SimpleCV.MachineLearning.TemporalColorTracker module
====================================================

.. automodule:: SimpleCV.MachineLearning.TemporalColorTracker
    :members:
    :show-inheritance:
