SimpleCV.Features.HaarLikeFeatureExtractor module
=================================================

.. automodule:: SimpleCV.Features.HaarLikeFeatureExtractor
    :members:
    :show-inheritance:
