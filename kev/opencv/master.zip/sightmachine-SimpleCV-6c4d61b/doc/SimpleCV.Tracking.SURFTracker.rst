SimpleCV.Tracking.SURFTracker module
====================================

.. automodule:: SimpleCV.Tracking.SURFTracker
    :members:
    :show-inheritance:
