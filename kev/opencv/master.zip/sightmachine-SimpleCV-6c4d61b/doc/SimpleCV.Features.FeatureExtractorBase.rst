SimpleCV.Features.FeatureExtractorBase module
=============================================

.. automodule:: SimpleCV.Features.FeatureExtractorBase
    :members:
    :show-inheritance:
