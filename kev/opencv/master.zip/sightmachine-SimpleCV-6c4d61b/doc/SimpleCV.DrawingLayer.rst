SimpleCV.DrawingLayer module
============================

.. automodule:: SimpleCV.DrawingLayer
    :members:
    :show-inheritance:
