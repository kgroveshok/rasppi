SimpleCV.Features.MorphologyFeatureExtractor module
===================================================

.. automodule:: SimpleCV.Features.MorphologyFeatureExtractor
    :members:
    :show-inheritance:
