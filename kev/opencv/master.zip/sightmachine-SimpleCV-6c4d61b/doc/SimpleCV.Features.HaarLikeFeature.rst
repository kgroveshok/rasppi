SimpleCV.Features.HaarLikeFeature module
========================================

.. automodule:: SimpleCV.Features.HaarLikeFeature
    :members:
    :show-inheritance:
