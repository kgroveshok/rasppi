SimpleCV.Tracking package
=========================

Submodules
----------

.. toctree::

   SimpleCV.Tracking.CAMShiftTracker
   SimpleCV.Tracking.LKTracker
   SimpleCV.Tracking.MFTracker
   SimpleCV.Tracking.SURFTracker
   SimpleCV.Tracking.TrackClass
   SimpleCV.Tracking.TrackSet

Module contents
---------------

.. automodule:: SimpleCV.Tracking
    :members:
    :show-inheritance:
