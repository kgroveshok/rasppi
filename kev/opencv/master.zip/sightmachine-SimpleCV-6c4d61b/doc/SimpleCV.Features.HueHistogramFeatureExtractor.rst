SimpleCV.Features.HueHistogramFeatureExtractor module
=====================================================

.. automodule:: SimpleCV.Features.HueHistogramFeatureExtractor
    :members:
    :show-inheritance:
