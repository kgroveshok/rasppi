SimpleCV.MachineLearning.TreeClassifier module
==============================================

.. automodule:: SimpleCV.MachineLearning.TreeClassifier
    :members:
    :show-inheritance:
