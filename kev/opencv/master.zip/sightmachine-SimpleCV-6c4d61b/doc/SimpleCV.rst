SimpleCV package
================

Subpackages
-----------

.. toctree::

    SimpleCV.Features
    SimpleCV.MachineLearning
    SimpleCV.Segmentation
    SimpleCV.Tracking

Submodules
----------

.. toctree::

   SimpleCV.Camera
   SimpleCV.Color
   SimpleCV.ColorModel
   SimpleCV.DFT
   SimpleCV.Display
   SimpleCV.DrawingLayer
   SimpleCV.Font
   SimpleCV.ImageClass
   SimpleCV.LineScan
   SimpleCV.Stream
   SimpleCV.base
