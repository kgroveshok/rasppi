SimpleCV.Tracking.MFTracker module
==================================

.. automodule:: SimpleCV.Tracking.MFTracker
    :members:
    :show-inheritance:
