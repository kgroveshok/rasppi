SimpleCV.Features.Features module
=================================

.. automodule:: SimpleCV.Features.Features
    :members:
    :show-inheritance:
