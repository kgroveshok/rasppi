SimpleCV.MachineLearning.ConfusionMatrix module
===============================================

.. automodule:: SimpleCV.MachineLearning.ConfusionMatrix
    :members:
    :show-inheritance:
