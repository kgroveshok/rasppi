SimpleCV.Features.BlobMaker module
==================================

.. automodule:: SimpleCV.Features.BlobMaker
    :members:
    :show-inheritance:
