SimpleCV.Tracking.TrackSet module
=================================

.. automodule:: SimpleCV.Tracking.TrackSet
    :members:
    :show-inheritance:
