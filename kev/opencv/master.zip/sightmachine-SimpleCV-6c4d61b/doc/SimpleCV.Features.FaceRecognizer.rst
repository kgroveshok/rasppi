SimpleCV.Features.FaceRecognizer module
=======================================

.. automodule:: SimpleCV.Features.FaceRecognizer
    :members:
    :show-inheritance:
