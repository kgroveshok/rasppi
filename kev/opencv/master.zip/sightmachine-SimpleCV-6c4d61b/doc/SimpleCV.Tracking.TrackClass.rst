SimpleCV.Tracking.TrackClass module
===================================

.. automodule:: SimpleCV.Tracking.TrackClass
    :members:
    :show-inheritance:
