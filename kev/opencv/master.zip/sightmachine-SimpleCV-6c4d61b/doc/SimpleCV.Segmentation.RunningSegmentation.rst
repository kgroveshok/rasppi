SimpleCV.Segmentation.RunningSegmentation module
================================================

.. automodule:: SimpleCV.Segmentation.RunningSegmentation
    :members:
    :show-inheritance:
